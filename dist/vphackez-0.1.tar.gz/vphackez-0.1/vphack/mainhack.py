
def runmain():
    print("Hi welcome to viper hack tools tutorial from NRTnarathip")
